/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (c) 2002-2003 Silicon Graphics, Inc.  All Rights Reserved.
 */

#define MACHVEC_PLATFORM_NAME	sn2
#define MACHVEC_PLATFORM_HEADER	<asm/machvec_sn2.h>
#include <asm/machvec_init.h>
